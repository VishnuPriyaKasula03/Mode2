package com.src;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.hamcrest.collection.IsIterableContainingInOrder;
import org.junit.Assert;
import org.junit.Test;

import com.main.dao.StudentDao;
import com.main.model.Student;
import com.main.model.TimeTable;
import com.main.service.StudentServiceImpl;

public class StudentDaoImplTest {

	/*@Test
	public void testSaveStudent() {
		StudentDao daoproxy=EasyMock.createMock(StudentDao.class);
		
		EasyMock.expect(daoproxy.findNameById(840)).andReturn("AnotherNIHITHA");
		EasyMock.expect(daoproxy.findNameById(420)).andReturn("NIHITHA");
		

		EasyMock.replay(daoproxy);
		
		StudentServiceImpl ssi=new StudentServiceImpl();
		ssi.setCdao(daoproxy);
		
		
		String name=csi.getNameById(420);
		assertNotNull(name);
		//System.out.println(name);
		assertEquals(name, "NIHITHA");
	}*/

	@Test
	public void testFetchStudentList() {
		StudentDao daoproxy=EasyMock.createMock(StudentDao.class);
		
		Student s1=new Student(1,"pk","pk#","class-I","fn","mn","12-10-2020","pk@gmail.com");
		Student s2=new Student(2,"ck","ck#","class-II","fn","mn","13-11-2010","ck@gmail.com");
		List<Student> list=new ArrayList<Student>();
		list.add(s1);
		list.add(s2);

		EasyMock.expect(daoproxy.fetchStudentList()).andReturn(list);
		

		EasyMock.replay(daoproxy);
		
		StudentServiceImpl ssi=new StudentServiceImpl();
		ssi.setStudentdao(daoproxy);
		
		
		List<Student> list1=ssi.fetchStudentList();
		/*for(int i=0;i<list1.size();i++)
		{
			System.out.println(list1.get(i).toString());
		}
		for(int i=0;i<list.size();i++)
		{
			System.out.println(list1.get(i).toString());
		}*/
		assertNotNull(list1);
		//System.out.println(name);
		assertEquals(list1, list);
		//Assert.assertThat(list1, IsIterableContainingInOrder.contains(list.toArray()));
	}

	@Test
	public void testFetchTimeTableList() {
		StudentDao daoproxy=EasyMock.createMock(StudentDao.class);
		
		TimeTable s1=new TimeTable(1,"class-I","9:00am to 10:am","shiva","java","http://www.teams.java.com","12-12-2020");
		TimeTable s2=new TimeTable(2,"class-I","10:30am to 12:30pm","rajesh","Web development","http://www.teams.web_development.com","13-12-2020");
		
		//Timetable for class-I
		List<TimeTable> list=new ArrayList<TimeTable>();
		list.add(s1);
		list.add(s2);
		
		TimeTable s4=new TimeTable(3,"class-II","9:00am to 10:am","vishnu","Web development","http://www.teams.web_development.com","13-12-2020");
		TimeTable s3=new TimeTable(4,"class-II","10:30am to 12:30pm","kumar","java","http://www.teams.java.com","12-12-2020");
		
		//Timetable for class-II
		List<TimeTable> list1=new ArrayList<TimeTable>();
		list1.add(s3);
		list1.add(s4);

		EasyMock.expect(daoproxy.fetchTimeTableList("class-I")).andReturn(list);
		EasyMock.expect(daoproxy.fetchTimeTableList("class-II")).andReturn(list);
		

		EasyMock.replay(daoproxy);
		
		StudentServiceImpl ssi=new StudentServiceImpl();
		ssi.setStudentdao(daoproxy);
		
		
		List<TimeTable> list2=ssi.fetchTimeTableList("class-I");
		/*for(int i=0;i<list1.size();i++)
		{
			System.out.println(list1.get(i).toString());
		}
		for(int i=0;i<list.size();i++)
		{
			System.out.println(list1.get(i).toString());
		}*/
		assertNotNull(list1);
		//System.out.println(name);
		assertEquals(list2, list);
		//Assert.assertThat(list1, IsIterableContainingInOrder.contains(list.toArray()));
	
	}

	/*@Test
	public void testFetchEnotesList() {
		fail("Not yet implemented");
	}

	@Test
	public void testFetchFeeList() {
		fail("Not yet implemented");
	}

	@Test
	public void testSaveFeedback() {
		fail("Not yet implemented");
	}

	@Test
	public void testFetchFeedbackList() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateStudent() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemoveStudent() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetStudentById() {
		fail("Not yet implemented");
	}*/

}
