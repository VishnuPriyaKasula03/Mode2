package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "TeacherFeedback")
public class TeacherFeedback {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer Feedbackid;
	@NotEmpty
	private String name;
	private String likes;
	private String dislikes;
	private String feedback;
	private int rating;
	
	public TeacherFeedback()
	{
		
	}
	public TeacherFeedback(Integer feedbackid, String name, String likes, String dislikes, String feedback,
			int rating) {
		super();
		Feedbackid = feedbackid;
		this.name = name;
		this.likes = likes;
		this.dislikes = dislikes;
		this.feedback = feedback;
		this.rating = rating;
	}
	public TeacherFeedback(String name, String likes, String dislikes, String feedback, int rating) {
		super();
		this.name = name;
		this.likes = likes;
		this.dislikes = dislikes;
		this.feedback = feedback;
		this.rating = rating;
	}
	
	
	public Integer getFeedbackid() {
		return Feedbackid;
	}
	public void setFeedbackid(Integer feedbackid) {
		Feedbackid = feedbackid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLikes() {
		return likes;
	}
	public void setLikes(String likes) {
		this.likes = likes;
	}
	public String getDislikes() {
		return dislikes;
	}
	public void setDislikes(String dislikes) {
		this.dislikes = dislikes;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	
	
	
	
}
