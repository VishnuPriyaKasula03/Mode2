package com.main.model;

public class StudentCredentials {

	private Integer StudentId;
	private String password;
	
}
