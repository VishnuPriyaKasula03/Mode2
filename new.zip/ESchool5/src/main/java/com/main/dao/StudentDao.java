package com.main.dao;

import java.util.List;

import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.StudentFeedback;
import com.main.model.TeacherFeedback;
import com.main.model.TimeTable;

/**
 * @author Rajesh Padmanabhuni
 *
 *         This StudentDao interface is the one which provides methods for
 *         StudentDao class for performing operations on Database.
 */
public interface StudentDao {

	void saveStudent(Student student);
	
	List<Student> fetchStudentList();
	
	List<TimeTable> fetchTimeTableList(String standard);
	
	List<Enotes> fetchEnotesList(String standard);

	List<Fee> fetchFeeList(Integer studentId);

	void saveFeedback(TeacherFeedback teacherFeedback);

	List<StudentFeedback> fetchFeedbackList(Integer studentid);

	void updateStudent(Student student);

	void removeStudent(int studentid);

	Student getStudentById(int studentid);

	void removeEnotes(int enotesId);

	Enotes getEnotesByEnotesId(int enotesId);

	void removeTimeTable(int timeTableId);

	TimeTable getTimeTableByTimeTableId(int timeTableId);
	

}
