package com.main.dao;

import java.util.List;

import com.main.model.Admin;
import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.StudentFeedback;
import com.main.model.Teacher;
import com.main.model.TeacherFeedback;
import com.main.model.TimeTable;

/**
 * @author Rajesh Padmanbhuni
 *
 *         This TeacherDao interface is the one which provides methods for
 *         TeacherDao class for performing operations on Database.
 */
public interface TeacherDao {

	
	void saveTimetable(TimeTable timetable);
	
	List<Teacher> fetchTeacherList();

	void saveEnotes(Enotes enotes);

	void saveFee(Fee fee);

	List<TeacherFeedback> fetchFeedbackList(String teacherName);

	void saveFeedback(StudentFeedback studentFeedback);

	void saveTeacher(Teacher teacher);

	List<Admin> fetchAdminList();

	void updateEnotes(Enotes enotes);

	void updateTimetable(TimeTable timetable);
}
