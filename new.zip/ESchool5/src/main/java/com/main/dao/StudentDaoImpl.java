package com.main.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.StudentFeedback;
import com.main.model.TeacherFeedback;
import com.main.model.TimeTable;



/**
 * @author Rajesh Padmanbhuni
 * 
 *         This StudentDao Will be providing the implementation for various
 *         database operations by using both SQL and HQL queries.
 */
@Repository
public class StudentDaoImpl implements StudentDao {

	Student currentStudent;
	private static Logger log = Logger.getLogger(StudentDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;

	public void saveStudent(Student student) {
		log.info("Inside saveStudent Method of StudentDao layer");
		sessionFactory.getCurrentSession().save(student);
	}

	
	public List<Student> fetchStudentList() {
		log.info("Inside fetchStudentList Method of StudentDao layer");
		List<Student> list  = sessionFactory.getCurrentSession().createQuery("from Student").list();
		return list;
	}

	
	public List<TimeTable> fetchTimeTableList(String standard) {
		log.info("Inside fetchTimeTableList Method of StudentDao layer");

		System.out.println("Tt"+standard);
		Query query = sessionFactory.getCurrentSession().createQuery("from TimeTable T where T.standard=:tstandard");
		query.setParameter("tstandard",standard);
		List<TimeTable> list = query.list();
		for(int i=0;i<list.size();i++)
		{
			System.out.println(list.get(i).toString());
		}
		return list;
	}

	
	public List<Enotes> fetchEnotesList(String standard) {
		log.info("Inside fetchEnotesList Method of StudentDao layer");

		System.out.println(standard);
		Query query = sessionFactory.getCurrentSession().createQuery("from Enotes E where E.standard=:estandard");
		query.setParameter("estandard",standard);
		List<Enotes> list = query.list();
		return list;
	}
	
	public List<Fee> fetchFeeList(Integer studentId) {
		log.info("Inside fetchFeeList Method of StudentDao layer");

		System.out.println(studentId);
		Query query = sessionFactory.getCurrentSession().createQuery("from Fee F where F.studentId=:fstudentId");
		query.setParameter("fstudentId",studentId);
		List<Fee> list = query.list();
		return list;
	}


	public void saveFeedback(TeacherFeedback teacherFeedback) {
		log.info("Inside saveFeedback Method of StudentDao layer");

		sessionFactory.getCurrentSession().save(teacherFeedback);
	}


	public List<StudentFeedback> fetchFeedbackList(Integer studentid) {
		log.info("Inside fetchFeedbackList Method of StudentDao layer");

		System.out.println(studentid);
		Query query = sessionFactory.getCurrentSession().createQuery("from StudentFeedback T where T.studentId=:estudentId");
		query.setParameter("estudentId",studentid);
		List<StudentFeedback> list = query.list();
		return list;
	}


	public void updateStudent(Student student) {
		log.info("Inside updateStudent Method of StudentDao layer");

		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.update(student);
	}


	public void removeStudent(int studentid) {
		log.info("Inside removeStudent Method of StudentDao layer");

		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		Student p = (Student) session.load(Student.class, new Integer(studentid));
		if(null != p){
			session.delete(p);
		}
	}


	public Student getStudentById(int studentid) {
		log.info("Inside getStudentById Method of StudentDao layer");
		
		Session session = this.sessionFactory.getCurrentSession();		
		Student p = (Student) session.load(Student.class, new Integer(studentid));
		System.out.println(p);
		return p;
	}


	public void removeEnotes(int enotesId) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		Enotes p = (Enotes) session.load(Enotes.class, new Integer(enotesId));
		if(null != p){
			session.delete(p);
		}
	}


	public Enotes getEnotesByEnotesId(int enotesId) {
		Session session = this.sessionFactory.getCurrentSession();		
		Enotes p = (Enotes) session.load(Enotes.class, new Integer(enotesId));
		System.out.println(p);
		return p;
	}


	public void removeTimeTable(int timeTableId) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		TimeTable p = (TimeTable) session.load(TimeTable.class, new Integer(timeTableId));
		if(null != p){
			session.delete(p);
		}
	}


	public TimeTable getTimeTableByTimeTableId(int timeTableId) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();		
		TimeTable p = (TimeTable) session.load(TimeTable.class, new Integer(timeTableId));
		System.out.println(p);
		return p;
	}
	
}
