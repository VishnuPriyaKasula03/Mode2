package com.main.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.main.model.Admin;
import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.StudentFeedback;
import com.main.model.Teacher;
import com.main.model.TeacherFeedback;
import com.main.model.TimeTable;

/**
 * @author Rajesh Padmanabhuni
 * 
 *         This TeacherDao Will be providing the implementation for various
 *         database operations by using both SQL and HQL queries.
 */
@Repository
public class TeacherDaoImpl implements TeacherDao {

	private static Logger log = Logger.getLogger(TeacherDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;


	public void saveTimetable(TimeTable timetable) {
		log.info("Inside saveTimetable Method of TeacherDao layer");

		sessionFactory.getCurrentSession().save(timetable);
	
		
	}

	
	public List<Teacher> fetchTeacherList() {
		log.info("Inside fetchTeacherList Method of TeacherDao layer");

		List<Teacher> list  = sessionFactory.getCurrentSession().createQuery("from Teacher").list();
		return list;
	}

	
	public void saveEnotes(Enotes enotes) {
		log.info("Inside saveEnotes Method of TeacherDao layer");

		sessionFactory.getCurrentSession().save(enotes);
		
		
	}

	
	public void saveFee(Fee fee) {
		log.info("Inside saveFee Method of TeacherDao layer");

		sessionFactory.getCurrentSession().save(fee);
		
	}


	public List<TeacherFeedback> fetchFeedbackList(String teacherName) {
		log.info("Inside fetchFeedbackList Method of TeacherDao layer");

		System.out.println(teacherName);
		Query query = sessionFactory.getCurrentSession().createQuery("from TeacherFeedback T where T.name=:ename");
		query.setParameter("ename",teacherName);
		List<TeacherFeedback> list = query.list();
		return list;
	}


	public void saveFeedback(StudentFeedback studentFeedback) {
		log.info("Inside saveFeedback Method of TeacherDao layer");

		// TODO Auto-generated method stub
		log.info("Inside saveFeedback Method of Dao layer");
		sessionFactory.getCurrentSession().save(studentFeedback);
	}


	public void saveTeacher(Teacher teacher) {
		log.info("Inside saveTeacher Method of TeacherDao layer");
		sessionFactory.getCurrentSession().save(teacher);
		
	}


	public List<Admin> fetchAdminList() {
		log.info("Inside fetchAdminList Method of TeacherDao layer");
		List<Admin> list  = sessionFactory.getCurrentSession().createQuery("from Admin").list();
        return list;
	}


	public void updateEnotes(Enotes enotes) {
		// TODO Auto-generated method stub
		log.info("Inside updateEnotes Method of TeacherDao layer");
		Session session = this.sessionFactory.getCurrentSession();
		session.update(enotes);
	}


	public void updateTimetable(TimeTable timetable) {
		// TODO Auto-generated method stub
		log.info("Inside updateTimetable Method of TeacherDao layer");
		Session session = this.sessionFactory.getCurrentSession();
		session.update(timetable);
	}

	
}