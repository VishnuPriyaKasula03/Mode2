package com.main.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.StudentDao;
import com.main.dao.TeacherDao;
import com.main.model.Admin;
import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.Teacher;
import com.main.model.TeacherFeedback;
import com.main.model.TimeTable;

@Service
@Transactional
public class TeacherServiceImpl implements TeacherService {

	private static Logger log = Logger.getLogger(TeacherServiceImpl.class);
	@Autowired
	private TeacherDao teacherdao;

	
	public void saveTimetable(TimeTable timetable) {
		log.info("Inside saveTimetable Method of TeacherService layer");
		teacherdao.saveTimetable(timetable);
	}



	
	public List<Teacher> fetchTeacherList() {
		log.info("Inside fetchTeacherList Method of TeacherService layer");

		return teacherdao.fetchTeacherList();
	}



	
	public void saveEnotes(Enotes enotes) {
		log.info("Inside saveEnotes Method of TeacherService layer");

		teacherdao.saveEnotes(enotes);
	}



	public void saveFee(Fee fee) {
		log.info("Inside saveFee Method of TeacherService layer");

		teacherdao.saveFee(fee);
	}




	public List<TeacherFeedback> fetchFeedbackList(String teacherName) {
		log.info("Inside fetchFeedbackList Method of TeacherService layer");
		List<TeacherFeedback> feedbacklist  = teacherdao.fetchFeedbackList(teacherName);
		return feedbacklist;
	}




	public void StudentFeedback(com.main.model.StudentFeedback studentFeedback) {
		log.info("Inside StudentFeedback Method of TeacherService layer");

		// TODO Auto-generated method stub
		teacherdao.saveFeedback(studentFeedback);
	}




	public void saveTeacher(Teacher teacher) {
		log.info("Inside saveTeacher Method of TeacherService layer");

        teacherdao.saveTeacher(teacher);
       
    }




	public List<Admin> fetchAdminList() {
		log.info("Inside fetchAdminList Method of TeacherService layer");

        List<Admin> fetchAdminList  = teacherdao.fetchAdminList();
        return fetchAdminList;
    }




	public void updateEnotes(Enotes enotes) {
		// TODO Auto-generated method stub
		teacherdao.updateEnotes(enotes);
	}




	public void updateTimetable(TimeTable timetable) {
		// TODO Auto-generated method stub
		teacherdao.updateTimetable(timetable);
	}

}
