export interface Department
{
    dept_id:number;
    dept_name:string;
}  